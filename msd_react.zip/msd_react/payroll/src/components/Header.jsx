import React from "react";
import "./Header.css";

const Header = () => {
  return (
    <nav className="navbar">
        <a href="#" className="logo flex items-center gap-2">
            <img
            src="https://img.icons8.com/color/48/employee-card.png"  // 🔹 replace with your logo path
            alt="Logo"
            className="w-10 h-10"
            />
        </a>
      <ul className="nav-links">
        <li><a href="#">Home</a></li>
        <li><a href="#">Contact</a></li>
        <li><a href="#">Admin</a></li>
      </ul>
    </nav>
  );
};
export default Header;