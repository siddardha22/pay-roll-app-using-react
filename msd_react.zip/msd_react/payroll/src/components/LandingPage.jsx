import React from "react";
import "./LandingPage.css";
import LoginCards from "../components/LoginCards";

export default function LandingPage() {
  return (
    <div>
      {/* Navbar */}
      {/* <header className="navbar">
        <div className="logo">
          <img
            src="https://img.icons8.com/color/48/employee-card.png"
            alt="Logo"
          />
          <h1>EMPLOYEE MANAGEMENT</h1>
        </div>

        <nav className="menu">
          <a href="#home" className="active">Home</a>
          <a href="#admin">Admin</a>
          <a href="#employee">Employee</a>
        </nav>
      </header> */}

      {/* Hero Section */}
      <section className="hero" id="home">
        <div className="overlay"></div>
        <div className="hero-text">
          <h2>
            Employee <span>Payroll Management</span>
            <br />
            System
          </h2>
        </div>
      </section>

      {/* Login Cards */}
      <section className="login-section">
        <h3>Login Options</h3>
        <LoginCards />
      </section>

      {/* Footer */}
      <footer className="footer">
        <p>© 2025 PayrollPro. All Rights Reserved.</p>
      </footer>
    </div>
  );
}
