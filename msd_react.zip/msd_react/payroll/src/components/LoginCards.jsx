import React from "react";
import "./LoginCards.css";

export default function LoginCards() {
  return (
    <div className="card-container">
      {/* Admin Card */}
      <div className="card">
        <img
          src="https://img.icons8.com/fluency/96/administrator-male.png"
          alt="Admin"
        />
        <h4>Admin Login</h4>
        <p>Manage employees, salaries, and HR operations.</p>
        <a href="#admin" className="btn">Login as Admin</a>
      </div>

      {/* Employee Card */}
      <div className="card">
        <img
          src="https://img.icons8.com/fluency/96/employee-card.png"
          alt="Employee"
        />
        <h4>Employee Login</h4>
        <p>Check salary details, attendance, and profile.</p>
        <a href="#employee" className="btn">Login as Employee</a>
      </div>
    </div>
  );
}
